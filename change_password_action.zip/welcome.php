<html lang="en">
  <head>
      <meta charset="utf-8"/>
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
      <meta name="description" content="About the site"/>
      <meta name="author" content="Author name"/>
      <title> Add New Lawyer </title>
    
      <!-- core CSS -->
      <link href="css/bootstrap.min.css" rel="stylesheet"/>
      <link href="css/font-awesome.min.css" rel="stylesheet"/>
      <link href="css/animate.min.css" rel="stylesheet"/>
      <link href="css/main.css" rel="stylesheet"/> 
  </head>

  <body> 
    <!-- following section is used for creating the menubar in the webpage -->
	<section id="header">
		<div class="row">  
			<div class="col-md-2" style="text-align: center;font-size: 40px;color:#FAFAD2;"> Welcome to </div>
			<div class="col-md-2" style="text-align: center;font-size: 40px;color:#FAFAD2;"> Rys Law Firm </div>
			<div class="col-md-10" style="text-align: right;color: #FFD700;"> 
				
			<section id = "section1">
		<div class="title" style="font-size: 40px; color: #FFE4B5;"> </div> 
		<div style="margin-left:20%; margin-right:20%; margin-top:80px; margin-bottom:80px;text-align:center;">
		<div class="row",style="padding:5px;"> 
			<a href="http://localhost/my_project/" style= "font-size: 20px; background:BLACK;text-align:center 40px;color:#FAFAD2;"> Admin Login</a>
			<br></br>
			<a href="show_students.php" style= "font-size: 20px; background:BLACK;text-align:center 40px;color:#FAFAD2;"> Lawyer Login</a>
			<br></br>
			<a href="clientlogin.php" style= "font-size: 20px; background:BLACK;text-align:center 40px;color:#FAFAD2;"> Client Login</a>
			<br></br>
		</div>	
			</div>
		</div>
	</section>
	